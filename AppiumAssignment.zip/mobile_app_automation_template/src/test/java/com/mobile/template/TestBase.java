package com.mobile.template;

import com.mobile.template.Utils.Base;
import com.mobile.template.Utils.InitiateDriver;
import com.mobile.template.Utils.PropertyReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.events.EventFiringWebDriverFactory;
import org.apache.commons.lang3.SystemUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import java.io.FileReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by codecraft on 08/11/16.
 */
public class TestBase{

    public AppiumDriver driver;
    public static HashMap<String,String> configProperties;
    public static HashMap<String,String> credentialsProperties;
    public static HashMap<String,String> testProperties;
    public static HashMap<String,String> getProperties;
    public static String windowsPath=System.getProperty("user.dir")+"\\src\\main\\resources\\"; //For Windows Properties path
    public static String linux_MacPath=System.getProperty("user.dir")+"/src/main/resources/";  //For Linux Properties path


    boolean jira;

    public TestBase() {
        configProperties = PropertyReader.getPropValues("config.properties");
        testProperties = PropertyReader.getPropValues("credentials.properties");
        String file = System.getenv("env")== null? "qa2":System.getenv("env");
        credentialsProperties = PropertyReader.getPropValues(file+".properties");

    }



    //use BeforeTest to rerun session after every suite
    @BeforeTest(alwaysRun=true)
    @Parameters(value={"config", "environment"})
    public void setup(String config_file, String environment)
    {
        try {
            getProperties = PropertyReader.getPropValues("config.properties");
            String deviceOS= System.getenv("os") == null? "":System.getenv("os");
            String env= System.getenv("device") == null? environment:System.getenv("device")+"("+deviceOS+")";
            System.out.println("env: ="+(System.getenv("env")== null? "qa2":System.getenv("env")));
            System.out.println("environment: ="+env);
            //For Local Running
            //InitiateDriver initiateDriver = new InitiateDriver();
            //driver = initiateDriver.getAppiumDriver();

            //For AWS
            //final String URL_STRING = "http://127.0.0.1:4723/wd/hub";

            //URL url_app = new URL(URL_STRING);
            JSONParser parser = new JSONParser();
            System.out.println(config_file);
            JSONObject config = (JSONObject) parser.parse(new FileReader(config_file));
            JSONObject envs = (JSONObject) config.get("environments");
            //Use a empty DesiredCapabilities object


            Map<String, String> envCapabilities = (Map<String, String>) envs.get(env);
            String os= ((Map<String, String>) envs.get(env)).get("os");
            String device = ((Map<String, String>) envs.get(env)).get("device");
            String runOn = ((Map<String, String>) envs.get(env)).get("runon");
            String deviceId = ((Map<String, String>) envs.get(env)).get("deviceid");
            String platform = ((Map<String, String>) envs.get(env)).get("platform");
            String server = (String) config.get("server");
            String user = (String) config.get("user");
            String key = (String) config.get("key");
            InitiateDriver initiateDriver = new InitiateDriver(user, key, server, runOn, device, os, deviceId);
            driver = initiateDriver.getAppiumDriver();
            //Use a higher value if your mobile elements take time to show up
//        driver.manage().timeouts().implicitlyWait(35, TimeUnit.SECONDS);
            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

            driver = EventFiringWebDriverFactory.getEventFiringWebDriver(driver, new EventListener());

            Base.driver = driver;
            //sleep(20);
            //driver.findElement(By.xpath("//input[@id='email']")).sendKeys(credentialsProperties.get("email"));
            //Pages.LoginPage().waitUntilLoginPageIsDisplayed();
        }
        catch(Exception e) {
            System.out.println(e);
            throw new RuntimeException("Driver setup has failed");
        }

    }


    @AfterTest(alwaysRun = true)
    public void teardown()
    {
        try {
            driver.closeApp();
            driver.quit();
        }
        catch(Exception e) {
            System.out.println(e);
//            throw new RuntimeException("Driver was already killed");
        }
    }




    public static void sleep(int timeout){
        try {
            Thread.sleep(timeout);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public HashMap<String, String> getDataFromCredentialsFile(){
        return PropertyReader.getPropValues("credentials.properties");
    }

    public boolean isAndroid(){
        HashMap<String,String> getProperties = PropertyReader.getPropValues("config.properties");
        String runOn = getProperties.get("PLATFORM");
        if(runOn.equalsIgnoreCase("ANDROID"))
            return true;
        return false;
    }



    public static String checkOS(){
        if (SystemUtils.IS_OS_WINDOWS) {
            return windowsPath;
        } else if (SystemUtils.IS_OS_MAC) {
            return linux_MacPath;
        } else if (SystemUtils.IS_OS_LINUX) {
            return linux_MacPath;
        } else{
            return null;
        }
    }


}
