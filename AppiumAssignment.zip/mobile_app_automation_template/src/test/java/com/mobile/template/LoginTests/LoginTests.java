package com.mobile.template.LoginTests;

import com.mobile.template.Pages;
import com.mobile.template.TestBase;
import io.appium.java_client.android.AndroidDriver;
import io.qameta.allure.Description;
import org.testng.Assert;
import org.testng.annotations.Test;

import static com.mobile.template.LoginPage.LoginPage.waitUntilLoginPageDisplayed;


public class LoginTests extends TestBase {




    @Test
    @Description("Verify Login to Amazon")
    public void verifyLogin() throws Exception
    {
        try
        {
            waitUntilLoginPageDisplayed();
            Pages.LoginPage().skipSignInPage();
            Pages.LoginPage().verifyLoginScreen(credentialsProperties.get("email"));
            Thread.sleep(2000);
            Pages.LoginPage().verifyLogin(credentialsProperties.get("password"));
            Pages.LoginPage().verifyHomescreen();
            Assert.assertTrue(Pages.LoginPage().verifyHomescreen());
        }
        catch (Exception e)
        {
            Assert.fail("Login unsuccessful");
        }


    }


    @Test
    public void verifySearchData()
    {
        Pages.LoginPage().skipSignInPage();
        Pages.LoginPage().verifyLoginScreen(credentialsProperties.get("email"));
        sleep(2000);
        Pages.LoginPage().verifyLogin(credentialsProperties.get("password"));
        Pages.LoginPage().verifyHomescreen();
        Pages.LoginPage().searchproduct();
        Pages.LoginPage().verifySearchResult();
        Assert.assertTrue(driver.getPageSource().contains("TV"));
    }




    @Test
    public void verifyOrderDetails()
    {
        Pages.LoginPage().skipSignInPage();
        Pages.LoginPage().verifyLoginScreen(credentialsProperties.get("email"));
        sleep(2000);
        Pages.LoginPage().verifyLogin(credentialsProperties.get("password"));
        Pages.LoginPage().verifyHomescreen();
        Pages.LoginPage().searchproduct();
        Pages.LoginPage().verifySearchResult();
        Pages.LoginPage().verifyOrderPage();
        Pages.LoginPage().buyNowButtonClick();
        Assert.assertTrue(driver.getPageSource().contains("Address Details"));


    }





}
