package com.mobile.template.Utils;

public class Mailcc {
}
