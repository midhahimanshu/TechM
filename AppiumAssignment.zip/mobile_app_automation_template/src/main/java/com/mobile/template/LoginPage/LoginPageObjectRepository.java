package com.mobile.template.LoginPage;

import com.mobile.template.Utils.Object_Base;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;

import java.util.List;

public class LoginPageObjectRepository extends Object_Base {

    public LoginPageObjectRepository(AppiumDriver driver){
        super(driver);
    }

    @iOSXCUITFindBy(xpath ="//XCUIElementTypeOther[@name='Please enter your email address']/preceding-sibling:: XCUIElementTypeTextField")
    @AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='email']")
    protected static WebElement emailField;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='Please enter your password']/preceding-sibling:: XCUIElementTypeSecureTextField")
    @AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='password']")
    protected static WebElement passwordField;





    //started


    @AndroidFindBy(id = "com.amazon.mShop.android.shopping:id/skip_sign_in_button")
    protected static WebElement skipSignInbtn;


    @AndroidFindBy(id = "com.amazon.mShop.android.shopping:id/action_bar_burger_icon")
    protected static WebElement hamburgerMenubtn;


    @AndroidFindBy(id = "com.amazon.mShop.android.shopping:id/action_bar_home_logo")
    public static WebElement signInbtn;

    //@AndroidFindBy(id = "ap_email_login")
    @AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='ap_email_login']")
    protected static WebElement logintxtbox;


    @AndroidFindBy(xpath = "//android.widget.Button[@text='Continue']")
    protected static WebElement continuebtn;


    @AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='ap_password']")
    protected static WebElement passwordtxtbox;


    @AndroidFindBy(xpath = "//android.widget.Button[@text='Login']")
    protected static WebElement loginbtn;

    @AndroidFindBy(xpath = "//android.widget.EditText[@text='Search']")
    protected static WebElement searchboxclick;


    @AndroidFindBy(id = "com.amazon.mShop.android.shopping:id/rs_search_src_text")
    protected static WebElement searchboxsearch;



    @AndroidFindBy(id = "item_title")
    public static List<WebElement> elementList;


    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.amazon.mShop.android.shopping:id/item_title']")
    protected static WebElement desctxt;




    @AndroidFindBy(xpath = "//android.view.View[@resource-id='a-autoid-11']")
    protected static WebElement buyNowbtn;















}