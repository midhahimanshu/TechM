package com.mobile.template.LoginPage;

import com.mobile.template.Utils.Base;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Keyboard;


import java.util.Random;

import static com.mobile.template.LoginPage.LoginPageObjectRepository.*;

public class LoginPage extends Base {

    private static LoginPageObjectRepository lp;

    public LoginPage() {
        lp = new LoginPageObjectRepository(driver);
    }




   //start

    public static void waitUntilLoginPageDisplayed() {
        waitUntilElementIsVisible(lp.skipSignInbtn);
    }


    public boolean skipSignInPage()
    {
        try
        {
            if(skipSignInbtn.isDisplayed()| skipSignInbtn.isEnabled())
            {
                skipSignInbtn.click();
                return true;
            }
            else
            {
                System.out.println("Skip SignIn button not found");
                return false;
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
            return false;
        }
    }




    public boolean verifyLoginScreen(String lgn)
    {
        try
        {
            if(hamburgerMenubtn.isDisplayed()| hamburgerMenubtn.isEnabled())
            {
                hamburgerMenubtn.click();
                signInbtn.click();
                logintxtbox.click();
                sleep(3);
                return true;
            }
            else
            {
                System.out.println(" Page not found");
                return false;
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
            return false;
        }
    }


    public boolean verifyLogin(String pwd)
    {
        try
        {
            if(logintxtbox.isDisplayed()| logintxtbox.isEnabled())
            {
                continuebtn.click();
                passwordtxtbox.click();
                passwordtxtbox.sendKeys(pwd);
                loginbtn.click();
                return true;
            }
            else
            {
                System.out.println(" Page not found");
                return false;
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
            return false;
        }
    }


    public boolean verifyHomescreen()
    {
        try
        {
            if(searchboxclick.isDisplayed()| searchboxclick.isEnabled())
            {
                searchboxclick.click();
                //searchboxsearch.sendKeys("tv");
                Actions action=new Actions((WebDriver) searchboxsearch);
                action.sendKeys("LED TV 65 inch").sendKeys(Keys.ENTER).build().perform();
                return true;
            }
            else
            {
                System.out.println(" data not found");
                return false;
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
            return false;
        }
    }



    public boolean searchproduct()
    {
        try
        {
            Random rand = new Random();
            int index = rand.nextInt(elementList.size()-1);
            elementList.get(index).click();
            System.out.println(elementList.size());
            return true;

        }
        catch (Exception e)
        {
            System.out.println("Data not found");
            Assert.fail();
            return false;
        }

    }


    public boolean verifySearchResult()
    {
        try
        {
            String str=desctxt.getText();
            System.out.println(str);
            return true;
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
            return false;
        }
    }


    public void scrollDown(){
        for (int i =0; i < 50; i++){
            if(isElementVisible(buyNowbtn)){
                buyNowbtn.click();
                break;
            }
        }
    }




    public void verifyOrderPage()
    {
        desctxt.click();
        scrollDown();

    }

    public void buyNowButtonClick()
    {
        buyNowbtn.click();
    }







}




